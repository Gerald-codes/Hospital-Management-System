package org.lucas.ui.framework;

/**
 * A generic interface for callback functions.
 */
public interface IGenericCallbackInterface {
    void callback();
}
