package org.lucas.ui.framework.views;

/**
 * Simple enum that defines the orientation of a listview
 */
public enum ListViewOrientation {
    HORIZONTAL,
    VERTICAL
}
