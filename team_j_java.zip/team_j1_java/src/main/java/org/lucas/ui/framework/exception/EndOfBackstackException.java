package org.lucas.ui.framework.exception;

public class EndOfBackstackException extends RuntimeException {
    public EndOfBackstackException(String message) {
        super(message);
    }
}
