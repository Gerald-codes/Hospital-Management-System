rootProject.name = "SCL"

